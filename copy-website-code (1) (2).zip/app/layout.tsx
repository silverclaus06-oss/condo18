import type React from "react"
import { Inter } from "next/font/google"
import "./globals.css"
import type { Metadata } from "next"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Roblox Condo Games - Premium Gaming Experience",
  description:
    "Discover the ultimate collection of exclusive Roblox condo games. Join thousands of players in immersive experiences.",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} font-sans antialiased`}>{children}</body>
    </html>
  )
}
