import { Gamepad2, Users, Zap, Play } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Gamepad2 className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold tracking-tight">
              ROBLOX<span className="text-primary">CONDO</span>
            </span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <Link href="#games" className="transition-colors hover:text-primary">
              Games
            </Link>
            <Link href="#features" className="transition-colors hover:text-primary">
              Features
            </Link>
            <Link href="#community" className="transition-colors hover:text-primary">
              Community
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login" className="hidden md:block text-sm font-medium hover:text-primary">
              Log in
            </Link>
            <Button>Get Started</Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-24 lg:py-32">
          <div className="absolute inset-0 z-0 opacity-20">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-purple-900/20" />
            <Image src="/abstract-neon-gaming-background.jpg" alt="Background" fill className="object-cover" priority />
          </div>
          <div className="container relative z-10 mx-auto px-4 text-center">
            <div className="mx-auto max-w-3xl space-y-6">
              <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl text-balance">
                Discover Exclusive{" "}
                <span className="bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent">
                  Roblox Condo
                </span>{" "}
                Games
              </h1>
              <p className="mx-auto max-w-2xl text-lg text-muted-foreground md:text-xl text-pretty">
                Join thousands of players in immersive experiences. The ultimate collection of premium games awaits you.
              </p>
              <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Button size="lg" className="h-12 w-full px-8 sm:w-auto text-base">
                  <Play className="h-4 w-4" /> Play Now
                </Button>
                <Button size="lg" variant="outline" className="h-12 w-full px-8 sm:w-auto text-base bg-transparent">
                  <Users className="h-4 w-4" /> Join Community
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Games Section */}
        <section id="games" className="py-20 bg-muted/50">
          <div className="container mx-auto px-4">
            <div className="mb-12 text-center">
              <h2 className="text-3xl font-bold tracking-tight md:text-4xl text-balance">Featured Games</h2>
              <p className="mt-4 text-muted-foreground">Explore our collection of exclusive Roblox condo games</p>
            </div>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {games.map((game, index) => (
                <div
                  key={index}
                  className="group relative overflow-hidden rounded-xl border bg-card transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10"
                >
                  <div className="aspect-[4/3] overflow-hidden relative">
                    <Image
                      src={game.image || "/placeholder.svg"}
                      alt={game.title}
                      width={400}
                      height={300}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 transition-opacity group-hover:opacity-100 flex items-center justify-center">
                      <Button
                        variant="secondary"
                        className="translate-y-4 transition-transform group-hover:translate-y-0"
                      >
                        Play Now
                      </Button>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-lg">{game.title}</h3>
                    <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{game.description}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">
                        {game.category}
                      </span>
                      <span className="text-xs text-muted-foreground flex items-center">
                        <Users className="h-3 w-3" /> {game.players}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20">
          <div className="container mx-auto px-4">
            <div className="mb-12 text-center">
              <h2 className="text-3xl font-bold tracking-tight md:text-4xl text-balance">Why Choose Our Platform?</h2>
              <p className="mt-4 text-muted-foreground">Experience the best Roblox condo games with premium features</p>
            </div>
            <div className="grid gap-8 md:grid-cols-3">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="rounded-lg border bg-card p-8 text-center transition-colors hover:border-primary/50"
                >
                  <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                    {feature.icon}
                  </div>
                  <h3 className="mb-3 text-xl font-bold">{feature.title}</h3>
                  <p className="text-muted-foreground text-pretty">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="border-t bg-muted/30 py-20">
          <div className="container mx-auto px-4">
            <div className="rounded-3xl bg-gradient-to-br from-purple-900/50 to-primary/20 p-8 md:p-16 text-center border border-primary/20 relative overflow-hidden">
              <div className="absolute top-0 right-0 -mt-10 -mr-10 h-64 w-64 rounded-full bg-primary/20 blur-3xl"></div>
              <div className="absolute bottom-0 left-0 -mb-10 -ml-10 h-64 w-64 rounded-full bg-blue-500/20 blur-3xl"></div>

              <h2 className="relative z-10 text-3xl font-bold tracking-tight md:text-4xl mb-6 text-balance">
                Ready to Start Playing?
              </h2>
              <p className="relative z-10 mx-auto max-w-2xl text-lg text-muted-foreground mb-10 text-pretty">
                Join our community today and discover amazing Roblox condo games. It's free to get started!
              </p>
              <div className="relative z-10">
                <Button size="lg" className="h-14 px-8 text-lg">
                  Get Started Now
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-background py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
            <div className="flex items-center gap-2">
              <Gamepad2 className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold">
                ROBLOX<span className="text-primary">CONDO</span>
              </span>
            </div>
            <p className="text-center text-sm text-muted-foreground md:text-left">
              &copy; {new Date().getFullYear()} Roblox Condo Games. All rights reserved.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-muted-foreground hover:text-primary text-sm">
                Privacy Policy
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary text-sm">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

// Data
const games = [
  {
    title: "Your Sus Gas Station Worker",
    description: "Work at the gas station in this interactive roleplay experience with surprising twists.",
    image: "/roblox-gas-station-neon.jpg",
    category: "Roleplay",
    players: "1.2k playing",
  },
  {
    title: "AI NPC Friends",
    description: "Chat and interact with advanced AI-powered NPCs in this social hangout experience.",
    image: "/futuristic-social-lounge-roblox.jpg",
    category: "Social",
    players: "856 playing",
  },
  {
    title: "Neko Girl Town",
    description: "Explore a vibrant town filled with neko characters, custom items, and endless adventures.",
    image: "/anime-town-colorful-roblox.jpg",
    category: "Adventure",
    players: "2.4k playing",
  },
  {
    title: "Weird Neko Untitled Game",
    description: "A unique and mysterious neko-themed adventure experience that defies explanation.",
    image: "/mysterious-abstract-game-world.jpg",
    category: "Mystery",
    players: "543 playing",
  },
]

const features = [
  {
    title: "Premium Games",
    description: "Access exclusive, high-quality condo games with regular updates and new content.",
    icon: <Gamepad2 className="h-6 w-6" />,
  },
  {
    title: "Active Community",
    description: "Join thousands of players in our vibrant gaming community on Discord and Roblox.",
    icon: <Users className="h-6 w-6" />,
  },
  {
    title: "Fast Access",
    description: "Quick loading times and instant access to all games through our optimized launcher.",
    icon: <Zap className="h-6 w-6" />,
  },
]
